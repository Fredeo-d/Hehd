# Frame Windows v2.4.1 (GD 2.2081)

Geode mod showing click frame windows (press/release) in real time.
FB frame counter style markers: thick outline, hollow center, frames count inside.

## Features
- Click markers at press/release points, colors by window size (green/yellow/red, 0 = impossible)
- Static status HUD (bottom-left): perfect-FPS of last click + ms window
- Click counter with configurable intervals (top-left, drag-friendly)
- HUD drag mode (F9) with saved positions
- Sounds per press/release sections via config/frame-sounds.json
- Session stats (F7), CSV export on quit
- Localization: English, Russian, Spanish (auto-detect or manual)

## Language
Default: auto (follows game language). Force via setting `Language` = en / ru / es.
Fallback: English.

## Build
```
geode sdk setup
geode build
```
or run build.bat / build.sh

## Frame Windows v2.4.1 (на русском)

Мод показывает окна кликов (нажатие/отжатие) в кадрах в реальном времени.
Кружки в стиле FB frame counter: толстая обводка, пустой центр, число кадров внутри.

### Возможности
- Кружки в точках нажатий/отжатий, цвет по размеру окна (зелёный/жёлтый/красный, 0 = кликать некуда)
- Статичный HUD слева снизу: FPS фрейм-перфекта последнего клика + окно в миллисекундах
- Счётчик кликов с настраиваемыми промежутками (слева сверху, поддерживает перетаскивание)
- Режим перетаскивания HUD (F9) с сохранением позиций
- Звуки по секциям press/release через config/frame-sounds.json
- Статистика сессии (F7), экспорт CSV при выходе
- Локализация: английский, русский, испанский (авто-детект или вручную)

### Язык
По умолчанию: авто (как в настройках игры). Принудительно: настройка `Language` = en / ru / es.
Если строки нет в выбранном языке — берётся английская.

### Сборка
```
geode sdk setup
geode build
```
или запусти build.bat / build.sh

# Frame Windows v2.4.1 (en espanol)

Mod de Geode que muestra las ventanas de clic (pulsacion/soltar) en cuadros en tiempo real.
Marcadores estilo FB frame counter: borde grueso, centro vacio, numero de cuadros dentro.

### Caracteristicas
- Marcadores en los puntos de pulsacion/soltar, color por tamano de ventana (verde/amarillo/rojo, 0 = imposible)
- HUD estatico (abajo a la izquierda): FPS perfecto del ultimo clic + ventana en ms
- Contador de clics con intervalos configurables (arriba a la izquierda, arrastrable)
- Modo arrastre del HUD (F9) con posiciones guardadas
- Sonidos por secciones press/release via config/frame-sounds.json
- Estadisticas de sesion (F7), exportacion CSV al salir
- Localizacion: ingles, ruso, espanol (autodeteccion o manual)

### Idioma
Por defecto: auto (segun el idioma del juego). Forzar con el ajuste `Language` = en / ru / es.
Si falta una cadena en el idioma elegido, se toma la inglesa.
