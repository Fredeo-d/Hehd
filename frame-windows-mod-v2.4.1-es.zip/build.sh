#!/bin/bash
set -e
if ! command -v geode &> /dev/null; then echo "Geode CLI not found. Install: https://github.com/geode-sdk/cli/releases"; exit 1; fi
if [ ! -d "$HOME/.geode/sdk" ] && [ -z "$GEODE_SDK" ]; then
  echo "Installing Geode SDK..."
  geode sdk install nightly --ready
  geode sdk setup
fi
geode build
