// Frame Windows v2.4.1 - Geode mod for GD 2.2081
// FB-style click markers + status HUD + drag mode + EN/RU/ES localization
#include <Geode/Geode.hpp>
#include <Geode/modify/PlayLayer.hpp>
#include <Geode/modify/GJBaseGameLayer.hpp>
#include <Geode/binding/PlayLayer.hpp>
#include <Geode/binding/GJBaseGameLayer.hpp>
#include <Geode/ui/GeodeUI.hpp>
#include <map>
#include <string>
#include <vector>
#include <fstream>
#include <sstream>
#include <chrono>
#include <algorithm>

using namespace geode::prelude;

// ---------- config ----------
struct FWConfig {
    double markerOutlineWidth = 3.0;
    double yellowThreshold    = 2.0;
    double greenThreshold     = 3.0;
    bool   showRelease        = true;
    bool   previewMarkers     = false;
    std::string counterSources = "press,orb";
    std::string counterIntervals = "[{\"min\":1,\"max\":2},{\"min\":3,\"max\":5},{\"min\":6,\"max\":999}]";
    bool   showStatusHUD      = true;
    double statusScale       = 1.0;
    double popupLifetime     = 1.0;
    std::string hudDragKey   = "F9";
    std::string toggleKey    = "TAB";
    int    cbfInputDelay     = 1;
    std::string language     = "auto";
};

static FWConfig CFG;

// ---------- localization ----------
struct Loc {
    std::map<std::string, std::string> table;
    bool loaded = false;
};

static Loc& fallbackLoc() {  // english is always the fallback
    static Loc l; return l;
}
static Loc& activeLoc() {
    static Loc l; return l;
}

static void loadLocaleFile(Loc& loc, const std::string& code) {
    auto res = Mod::get()->getResourcesDir();
    std::ifstream f((res / ("locales/" + code + ".json")).string());
    if (!f.is_open()) {
        f.open(fmt::format("resources/locales/{}.json", code));
    }
    if (!f.is_open()) return;
    std::stringstream ss; ss << f.rdbuf();
    auto json = matjson::parse(ss.str());
    if (!json.isOk()) return;
    loc.loaded = true;
    auto obj = json.unwrap();
    for (auto& [key, val] : obj) {
        if (val.isString()) loc.table[key] = val.asString().unwrapOr(key);
    }
}

static std::string resolveLangCode() {
    auto setting = CFG.language;
    if (setting != "auto") return setting;
    auto lang = GameManager::get()->m_gameLanguage;
    std::string s = lang.value_or("en_US");
    if (s.rfind("ru", 0) == 0) return "ru";
    if (s.rfind("es", 0) == 0) return "es";
    return "en";
}

static void reloadLocalization() {
    activeLoc().table.clear();
    loadLocaleFile(fallbackLoc(), "en");
    std::string code = resolveLangCode();
    loadLocaleFile(activeLoc(), code);
}

static std::string tr(const std::string& key, const std::map<std::string, std::string>& vars = {}) {
    std::string s;
    auto& act = activeLoc();
    if (act.loaded && act.table.count(key)) s = act.table[key];
    else if (fallbackLoc().table.count(key)) s = fallbackLoc().table[key];
    else s = key;
    for (auto& [k, v] : vars) {
        size_t pos = s.find("{" + k + "}");
        while (pos != std::string::npos) {
            s.replace(pos, k.size() + 2, v);
            pos = s.find("{" + k + "}");
        }
    }
    return s;
}

// ---------- click recording ----------
enum class ClickKind { Press, Release, Orb, Dash };

struct ClickRecord {
    double x = 0, y = 0;
    int    framesWindow = 0;
    double framesExact = 0;
    double perfectFps = 0;
    double msWindow = 0;
    ClickKind kind;
    std::chrono::steady_clock::time_point time;
};

static std::vector<ClickRecord> g_clicks;
static std::map<std::string, int> g_counterBuckets;
static std::vector<std::pair<double,double>> g_intervals;
static bool g_enabled = true;
static bool g_dragMode = false;
static double g_lastPhysicsFrame = 0;
static double g_frameAccum = 0;
static int    g_extraInFrame = 0;
static double g_currentFps = 60.0;

static constexpr int kTagCounterPanel = 0xF001;
static constexpr int kTagStatusHud    = 0xF002;
static constexpr int kTagMarker       = 0xF010;

static std::map<std::string, CCPoint> g_savedPos;

static bool sourceEnabled(ClickKind k) {
    auto& src = CFG.counterSources;
    auto has = [&](const char* s){ return src.find(s) != std::string::npos; };
    switch (k) {
        case ClickKind::Press:   return has("press");
        case ClickKind::Release: return has("release");
        case ClickKind::Orb:     return has("orb");
        case ClickKind::Dash:    return has("dash");
    }
    return false;
}

static void loadIntervals() {
    g_intervals.clear();
    auto json = matjson::parse(CFG.counterIntervals);
    if (!json.isOk()) return;
    auto arr = json.unwrap();
    if (!arr.isArray()) return;
    for (auto& item : arr) {
        if (!item.isObject()) continue;
        auto minV = item["min"].asDouble();
        auto maxV = item["max"].asDouble();
        if (minV.isOk() && maxV.isOk())
            g_intervals.push_back({ minV.unwrap(), maxV.unwrap() });
    }
}

static void loadDragPositions() {
    auto saved = Mod::get()->getSavedValue<std::map<std::string, std::array<float,2>>>("hud-positions");
    g_savedPos.clear();
    for (auto& [k, v] : saved)
        g_savedPos[k] = { v[0], v[1] };
}

static void saveDragPosition(const std::string& name, CCPoint frac) {
    g_savedPos[name] = frac;
    std::map<std::string, std::array<float,2>> out;
    for (auto& [k, v] : g_savedPos) out[k] = { v.x, v.y };
    Mod::get()->setSavedValue<std::map<std::string, std::array<float,2>>>("hud-positions", out);
}

static void applySavedPosition(cocos2d::CCNode* node, const std::string& name, CCPoint defFrac) {
    CCSize win = CCDirector::get()->getWinSize();
    if (g_savedPos.count(name)) {
        auto f = g_savedPos[name];
        node->setPosition({ f.x * win.width, f.y * win.height });
    } else {
        node->setPosition({ defFrac.x * win.width, defFrac.y * win.height });
    }
}

// ---------- colors ----------
static ccColor3B windowColor(int frames) {
    if (frames <= 0) return {255, 59, 48};
    if (frames < CFG.yellowThreshold) return {255, 204, 0};
    return {76, 217, 100};
}

// ---------- CSV export ----------
static void exportCsv() {
    auto dir = Mod::get()->getSaveDir();
    auto path = dir / "frame-windows.csv";
    std::ofstream f(path);
    if (!f.is_open()) return;
    f << "x,y,kind,frames,frames_exact,perfect_fps,ms_window\n";
    for (auto& c : g_clicks) {
        const char* kind = c.kind == ClickKind::Release ? "release" :
                           c.kind == ClickKind::Orb ? "orb" :
                           c.kind == ClickKind::Dash ? "dash" : "press";
        f << c.x << "," << c.y << "," << kind << "," << c.framesWindow << ","
          << c.framesExact << "," << c.perfectFps << "," << c.msWindow << "\n";
    }
    Notification::create(tr("csv.exported"), NotificationIcon::Success, 2.0f)->show();
}

// ---------- session stats (F7) ----------
static void showStats() {
    if (g_clicks.empty()) return;
    std::vector<double> fpsV, msV;
    for (auto& c : g_clicks) { fpsV.push_back(c.perfectFps); msV.push_back(c.msWindow); }
    auto median = [](std::vector<double>& v) {
        std::sort(v.begin(), v.end());
        size_t n = v.size();
        return n % 2 ? v[n/2] : (v[n/2 - 1] + v[n/2]) / 2.0;
    };
    std::string body = tr("stats.title") + "\n"
        + fmt::format(fmt::runtime(tr("stats.median.fps")), fmt::arg("fps", median(fpsV))) + "\n"
        + fmt::format(fmt::runtime(tr("stats.median.ms")), fmt::arg("ms", median(msV))) + "\n"
        + fmt::format(fmt::runtime(tr("stats.clicks")), fmt::arg("n", g_clicks.size()));
    FLAlertLayer::create("Frame Windows", body, "OK")->show();
}

// ---------- drawing: FB-style ring markers ----------
static void updateStatusHud(double perfectFps, double ms);

static void spawnClickMarker(ClickKind kind, double framesExact, double x, double y, bool isRelease) {
    if (!g_enabled) return;
    auto pl = PlayLayer::get();
    if (!pl) return;

    int framesInt = (int)std::floor(framesExact);
    auto color = windowColor(framesInt);

    double dt = 1.0 / g_currentFps;
    double ms = framesExact * dt * 1000.0;
    double perfectFps = g_currentFps; // refined by caller with phase offset

    ClickRecord rec;
    rec.x = x; rec.y = y;
    rec.framesExact = framesExact;
    rec.framesWindow = framesInt;
    rec.msWindow = ms;
    rec.perfectFps = perfectFps;
    rec.kind = kind;
    rec.time = std::chrono::steady_clock::now();
    g_clicks.push_back(rec);

    for (size_t i = 0; i < g_intervals.size(); ++i) {
        if (framesExact >= g_intervals[i].first && framesExact < g_intervals[i].second) {
            g_counterBuckets[std::to_string(i)]++;
            break;
        }
    }

    auto layer = pl->m_objectLayer;

    auto ring = CCDrawNode::create();
    float r = 22.0f;
    ring->drawCircle(CCPoint(0,0), r, color, (float)CFG.markerOutlineWidth, color);
    ring->setPosition({ (float)x, (float)y });
    ring->setTag(kTagMarker);
    layer->addChild(ring, 500);

    std::string label = std::to_string(framesInt);
    if (g_extraInFrame > 0 && !isRelease) label += " +";
    auto text = CCLabelBMFont::create(label.c_str(), "bigFont.fnt");
    text->setScale(0.45f);
    text->setColor(color);
    text->setPosition({ (float)x, (float)y });
    text->setTag(kTagMarker);
    layer->addChild(text, 501);

    if (isRelease) {
        ring->setOpacity(160);
        text->setOpacity(160);
    }

    ring->runAction(CCSequence::create(
        CCDelayTime::create(CFG.popupLifetime),
        CCFadeOut::create(0.4f),
        CCRemoveSelf::create(),
        nullptr));
    text->runAction(CCSequence::create(
        CCDelayTime::create(CFG.popupLifetime),
        CCFadeOut::create(0.4f),
        CCRemoveSelf::create(),
        nullptr));
}

// ---------- status HUD (static bottom-left) ----------
static CCNode* getStatusHud(PlayLayer* pl) {
    auto node = pl->getChildByTag(kTagStatusHud);
    if (!node) {
        node = CCNode::create();
        node->setTag(kTagStatusHud);
        pl->addChild(node, 1000);
        auto fpsL = CCLabelBMFont::create("", "bigFont.fnt");
        fpsL->setTag(1); fpsL->setScale(0.4f);
        node->addChild(fpsL);
        auto msL = CCLabelBMFont::create("", "bigFont.fnt");
        msL->setTag(2); msL->setScale(0.4f);
        msL->setPosition({0, -18});
        node->addChild(msL);
        applySavedPosition(node, "status", {0.02f, 0.05f});
    }
    node->setVisible(CFG.showStatusHUD);
    node->setScale(CFG.statusScale);
    return node;
}

static void updateStatusHud(double perfectFps, double ms) {
    auto pl = PlayLayer::get();
    if (!pl || !CFG.showStatusHUD) return;
    auto node = getStatusHud(pl);
    auto fpsL = (CCLabelBMFont*)node->getChildByTag(1);
    auto msL  = (CCLabelBMFont*)node->getChildByTag(2);
    if (fpsL) fpsL->setString(tr("hud.fps", {{"fps", fmt::format("{:.1f}", perfectFps)}}).c_str());
    if (msL)  msL->setString(fmt::format(fmt::runtime(tr("hud.ms")), fmt::arg("ms", ms)).c_str());
}

// ---------- counter panel (top-left) ----------
static void rebuildCounterPanel(PlayLayer* pl) {
    auto old = pl->getChildByTag(kTagCounterPanel);
    if (old) old->removeFromParent();
    auto node = CCNode::create();
    node->setTag(kTagCounterPanel);
    pl->addChild(node, 999);

    float y = 0;
    auto title = CCLabelBMFont::create(tr("counter.title").c_str(), "goldFont.fnt");
    title->setScale(0.5f);
    node->addChild(title);
    y -= 20;

    for (size_t i = 0; i < g_intervals.size(); ++i) {
        std::string lo = fmt::format("{}", g_intervals[i].first);
        std::string hi = g_intervals[i].second >= 999 ? "+" : fmt::format("{}", g_intervals[i].second);
        int cnt = g_counterBuckets[std::to_string(i)];
        auto l = CCLabelBMFont::create(fmt::format("{}-{}: {}", lo, hi, cnt).c_str(), "bigFont.fnt");
        l->setScale(0.4f);
        l->setPosition({0, y});
        node->addChild(l);
        y -= 16;
    }
    auto cbf = CCLabelBMFont::create(
        (CFG.cbfInputDelay > 0 ? tr("counter.cbf") : tr("counter.cbf.off")).c_str(), "bigFont.fnt");
    cbf->setScale(0.35f);
    cbf->setColor({120, 180, 255});
    cbf->setPosition({0, y - 4});
    node->addChild(cbf);

    applySavedPosition(node, "counter", {0.02f, 0.95f});
}

// ---------- drag mode ----------
struct DragCtx { std::string name; CCNode* node; CCPoint grabOffset; };
static DragCtx g_dragCtx;

static void setDragMode(bool on) {
    g_dragMode = on;
    if (!PlayLayer::get()) return;
    Notification::create(tr(on ? "drag.on" : "drag.off"),
        on ? NotificationIcon::Info : NotificationIcon::Success, 2.5f)->show();
}

static void tryBeginDrag(CCPoint worldPos) {
    auto pl = PlayLayer::get();
    if (!pl) return;
    for (auto& [name, tag] : std::map<std::string,int>{{"counter", kTagCounterPanel}, {"status", kTagStatusHud}}) {
        auto node = pl->getChildByTag(tag);
        if (!node) continue;
        auto box = node->boundingBox();
        if (box.containsPoint(node->convertToNodeSpace(worldPos))) {
            g_dragCtx = { name, node, worldPos - node->getPosition() };
            return;
        }
    }
}

static void dragMoved(CCPoint worldPos) {
    if (!g_dragMode || !g_dragCtx.node) return;
    auto win = CCDirector::get()->getWinSize();
    CCPoint p = worldPos - g_dragCtx.grabOffset;
    p.x = std::clamp(p.x, 0.f, win.width);
    p.y = std::clamp(p.y, 0.f, win.height);
    g_dragCtx.node->setPosition(p);
}

static void endDrag() {
    if (!g_dragCtx.node) return;
    auto win = CCDirector::get()->getWinSize();
    auto p = g_dragCtx.node->getPosition();
    saveDragPosition(g_dragCtx.name, { p.x / win.width, p.y / win.height });
    g_dragCtx.node = nullptr;
    Notification::create(tr("drag.saved"), NotificationIcon::Success, 1.5f)->show();
}

// ---------- sounds ----------
static std::map<std::string, std::vector<std::pair<int,int>>> g_soundRules;
static void loadSounds() {
    g_soundRules.clear();
    auto path = Mod::get()->getConfigDir() / "frame-sounds.json";
    std::ifstream f(path);
    if (!f.is_open()) return;
    std::stringstream ss; ss << f.rdbuf();
    auto json = matjson::parse(ss.str());
    if (!json.isOk()) return;
    auto obj = json.unwrap();
    for (auto& [sec, rules] : obj) {
        if (!rules.isArray()) continue;
        for (auto& r : rules) {
            if (!r.isObject()) continue;
            auto minF = r["min-frames"].asInt();
            auto maxF = r["max-frames"].asInt();
            if (minF.isOk() && maxF.isOk())
                g_soundRules[sec].push_back({ minF.unwrap(), maxF.unwrap() });
        }
    }
}

static void playSoundFor(const std::string& section, int frames) {
    if (!g_soundRules.count(section)) return;
    for (auto& [lo, hi] : g_soundRules[section]) {
        if (frames >= lo && frames <= hi) {
            FMODAudioEngine::get()->playEffect("gold02_01.ogg");
            break;
        }
    }
}

// ---------- hooks ----------
class $modify(FWPlayLayer, PlayLayer) {
    bool init(GJGameLevel* level, bool useReplay, bool dontCreateObjects) {
        if (!PlayLayer::init(level, useReplay, dontCreateObjects)) return false;
        CFG.markerOutlineWidth = Mod::get()->getSettingValue<double>("marker-outline-width");
        CFG.yellowThreshold    = Mod::get()->getSettingValue<double>("yellow-threshold");
        CFG.greenThreshold     = Mod::get()->getSettingValue<double>("green-threshold");
        CFG.showRelease        = Mod::get()->getSettingValue<bool>("show-release-markers");
        CFG.previewMarkers     = Mod::get()->getSettingValue<bool>("preview-markers");
        CFG.counterSources     = Mod::get()->getSettingValue<std::string>("counter-sources");
        CFG.counterIntervals   = Mod::get()->getSettingValue<std::string>("counter-intervals");
        CFG.showStatusHUD      = Mod::get()->getSettingValue<bool>("show-status-hud");
        CFG.statusScale        = Mod::get()->getSettingValue<double>("status-scale");
        CFG.popupLifetime      = Mod::get()->getSettingValue<double>("popup-lifetime");
        CFG.hudDragKey         = Mod::get()->getSettingValue<std::string>("hud-drag-key");
        CFG.toggleKey          = Mod::get()->getSettingValue<std::string>("toggle-key");
        CFG.cbfInputDelay      = (int)Mod::get()->getSettingValue<int64_t>("cbf-input-delay");
        CFG.language           = Mod::get()->getSettingValue<std::string>("language");

        reloadLocalization();
        loadIntervals();
        loadSounds();
        loadDragPositions();
        g_clicks.clear();
        g_counterBuckets.clear();
        g_extraInFrame = 0;
        rebuildCounterPanel(this);
        getStatusHud(this);
        return true;
    }

    void postUpdate(float dt) {
        PlayLayer::postUpdate(dt);
        if (dt > 0) g_currentFps = 1.0 / dt;
    }

    void resetLevelVariables() {
        PlayLayer::resetLevelVariables();
        g_counterBuckets.clear();
        g_extraInFrame = 0;
        rebuildCounterPanel(this);
        getStatusHud(this);
    }

    bool ccTouchBegan(cocos2d::CCTouch* touch, cocos2d::CCEvent* event) {
        if (g_dragMode) { tryBeginDrag(touch->getLocation()); return true; }
        return PlayLayer::ccTouchBegan(touch, event);
    }

    void ccTouchMoved(cocos2d::CCTouch* touch, cocos2d::CCEvent* event) {
        if (g_dragMode) { dragMoved(touch->getLocation()); return; }
        PlayLayer::ccTouchMoved(touch, event);
    }

    void ccTouchEnded(cocos2d::CCTouch* touch, cocos2d::CCEvent* event) {
        if (g_dragMode) { endDrag(); return; }
        PlayLayer::ccTouchEnded(touch, event);
    }

    void onQuit() {
        PlayLayer::onQuit();
        exportCsv();
    }
};

class $modify(FWBaseGameLayer, GJBaseGameLayer) {
    void pushButton(int btn, bool idk) {
        GJBaseGameLayer::pushButton(btn, idk);
        handleInput(true, btn);
    }
    void releaseButton(int btn, bool idk) {
        GJBaseGameLayer::releaseButton(btn, idk);
        handleInput(false, btn);
    }

    void handleInput(bool down, int btn) {
        auto pl = PlayLayer::get();
        if (!pl || !g_enabled) return;

        auto player = pl->m_player1;
        double x = player ? player->getPosition().x : 0;
        double y = player ? player->getPosition().y : 0;

        double physDt = 1.0 / 240.0;
        double sinceTick = std::fmod(pl->m_gameState.m_time, physDt);
        double offsetMs = sinceTick * 1000.0 + CFG.cbfInputDelay * physDt * 1000.0;
        if (offsetMs >= physDt * 1000.0) offsetMs -= physDt * 1000.0;

        double fps = g_currentFps;
        if (fps < 1) fps = 60;
        double framesExact = (physDt / (1.0 / fps));

        ClickKind kind = down ? ClickKind::Press : ClickKind::Release;
        if (!sourceEnabled(kind)) return;

        g_extraInFrame = (g_extraInFrame > 0) ? g_extraInFrame + 1 : 0;

        int framesInt = (int)std::floor(framesExact);
        auto color = windowColor(framesInt);
        double ms = framesExact * (1.0 / fps) * 1000.0;
        double perfectFps = offsetMs > 0.01 ? 1000.0 / offsetMs : fps;

        ClickRecord rec;
        rec.x = x; rec.y = y;
        rec.framesExact = framesExact;
        rec.framesWindow = framesInt;
        rec.msWindow = ms;
        rec.perfectFps = perfectFps;
        rec.kind = kind;
        rec.time = std::chrono::steady_clock::now();
        g_clicks.push_back(rec);

        for (size_t i = 0; i < g_intervals.size(); ++i) {
            if (framesExact >= g_intervals[i].first && framesExact < g_intervals[i].second) {
                g_counterBuckets[std::to_string(i)]++;
                break;
            }
        }

        auto layer = pl->m_objectLayer;
        auto ring = CCDrawNode::create();
        ring->drawCircle(CCPoint(0,0), 22.0f, color, (float)CFG.markerOutlineWidth, color);
        ring->setPosition({ (float)x, (float)y });
        ring->setTag(kTagMarker);
        layer->addChild(ring, 500);

        std::string label = std::to_string(framesInt);
        if (g_extraInFrame > 0 && !down) {} // plus only for presses
        else if (g_extraInFrame > 0) label += " +";
        auto text = CCLabelBMFont::create(label.c_str(), "bigFont.fnt");
        text->setScale(0.45f);
        text->setColor(color);
        text->setPosition({ (float)x, (float)y });
        text->setTag(kTagMarker);
        layer->addChild(text, 501);

        if (!down) {
            ring->setOpacity(160);
            text->setOpacity(160);
        }

        ring->runAction(CCSequence::create(
            CCDelayTime::create(CFG.popupLifetime),
            CCFadeOut::create(0.4f),
            CCRemoveSelf::create(),
            nullptr));
        text->runAction(CCSequence::create(
            CCDelayTime::create(CFG.popupLifetime),
            CCFadeOut::create(0.4f),
            CCRemoveSelf::create(),
            nullptr));

        updateStatusHud(perfectFps, ms);
        playSoundFor(down ? "press" : "release", framesInt);

        if (!down) g_extraInFrame = 0;
    }
};

#include <Geode/modify/CCKeyboardDispatcher.hpp>
class $modify(FWKeys, cocos2d::CCKeyboardDispatcher) {
    bool dispatchKeyboardMSG(cocos2d::enumKeyCodes key, bool isKeydown, bool repeat) {
        if (isKeydown && !repeat) {
            if (key == cocos2d::KEY_F7) showStats();
            if (key == cocos2d::KEY_F8) {
                g_counterBuckets.clear();
                if (auto pl = PlayLayer::get()) rebuildCounterPanel(pl);
            }
            if (key == cocos2d::KEY_F9) setDragMode(!g_dragMode);
        }
        return CCKeyboardDispatcher::dispatchKeyboardMSG(key, isKeydown, repeat);
    }
};
