@echo off
where geode >nul 2>nul
if errorlevel 1 (
  echo Geode CLI not found. Install from: https://github.com/geode-sdk/cli/releases
  exit /b 1
)
if "%GEODE_SDK%"=="" (
  if not exist "%USERPROFILE%\.geode\sdk" (
    echo Installing Geode SDK...
    geode sdk install nightly --ready
    geode sdk setup
  )
)
geode build
